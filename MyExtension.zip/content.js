let isContentHidden = true;

const sites = {
    youtube: {
        selectors: [
            'div#contents.style-scope.ytd-rich-grid-renderer',
            '.ytp-endscreen-content',
            '.ytp-ce-element'
        ],
        additionalActions: function() {
            this.disableAutoplay();
        },
        disableAutoplay: function() {
            const autoplayToggle = document.querySelector('.ytp-autonav-toggle-button');
            if (autoplayToggle && autoplayToggle.getAttribute('aria-checked') === 'true') {
                autoplayToggle.click();
            }

            if (window.yt && window.yt.player && window.yt.player.getPlayer) {
                const player = window.yt.player.getPlayer();
                if (player && player.pauseVideo) {
                    const originalPauseVideo = player.pauseVideo;
                    player.pauseVideo = function() {
                        originalPauseVideo.apply(this, arguments);
                        if (this.cancelPlayback) {
                            this.cancelPlayback();
                        }
                    };
                }
            }
        }
    },
    facebook: {
        getNewsfeed: function() {
            const mainContent = document.querySelector('div[role="main"]');
            if (!mainContent) return null;

            // Look for a large div containing multiple posts
            const possibleFeeds = mainContent.querySelectorAll('div > div > div > div > div > div > div > div');
            for (let feed of possibleFeeds) {
                if (feed.querySelector('[role="article"]')) {
                    return feed;
                }
            }
            return null;
        }
    }
};

function createToggleButton(element) {
    let container = element.previousElementSibling;
    if (container && container.classList.contains('algorithm-escape-toggle-container')) {
        return container.querySelector('.algorithm-escape-toggle');
    }

    container = document.createElement('div');
    container.className = 'algorithm-escape-toggle-container';

    const button = document.createElement('button');
    button.className = 'algorithm-escape-toggle';
    button.textContent = 'Show Hidden Content';

    const text = document.createElement('p');
    text.className = 'algorithm-escape-text';
    text.textContent = 'You are escaping the algorithm 😎';

    container.appendChild(button);
    container.appendChild(text);

    element.parentNode.insertBefore(container, element);

    button.addEventListener('click', toggleContent);
    return button;
}

function toggleContent() {
    isContentHidden = !isContentHidden;
    hideOrShowContent();
}

function updateToggleButton(button) {
    if (button) {
        const text = button.nextElementSibling;
        button.textContent = isContentHidden ? 'Show Hidden Content' : 'Hide Content';
        text.textContent = isContentHidden ? 'You are escaping the algorithm 😎' : 'Don\'t get sucked in 😱';
    }
}

function getCurrentSite() {
    if (window.location.hostname.includes('youtube.com')) return 'youtube';
    if (window.location.hostname.includes('facebook.com')) return 'facebook';
    return null;
}

function hideOrShowContent() {
    const currentSite = getCurrentSite();
    if (currentSite) {
        if (currentSite === 'youtube') {
            sites.youtube.selectors.forEach(selector => {
                const elements = document.querySelectorAll(selector);
                elements.forEach(element => {
                    element.classList.toggle('hidden-by-extension', isContentHidden);
                    const button = element.previousElementSibling.querySelector('.algorithm-escape-toggle');
                    updateToggleButton(button);
                });
            });

            if (isContentHidden) {
                sites.youtube.additionalActions();
            }
        } else if (currentSite === 'facebook') {
            const newsfeed = sites.facebook.getNewsfeed();
            if (newsfeed) {
                newsfeed.classList.toggle('hidden-by-extension', isContentHidden);
                const button = newsfeed.previousElementSibling.querySelector('.algorithm-escape-toggle');
                updateToggleButton(button);
            }
        }
    }
}

function initializeSite() {
    const currentSite = getCurrentSite();
    if (currentSite === 'youtube') {
        sites.youtube.selectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                if (!element.classList.contains('hidden-by-extension')) {
                    element.classList.add('hidden-by-extension');
                    createToggleButton(element);
                }
            });
        });
        sites.youtube.additionalActions();
    } else if (currentSite === 'facebook') {
        const newsfeed = sites.facebook.getNewsfeed();
        if (newsfeed && !newsfeed.classList.contains('hidden-by-extension')) {
            newsfeed.classList.add('hidden-by-extension');
            createToggleButton(newsfeed);
        }
    }
}

// Run initialization when the page loads
initializeSite();

// Use a MutationObserver to handle dynamically loaded content
const observer = new MutationObserver(() => {
    if (isContentHidden) {
        initializeSite();
    }
});

observer.observe(document.body, { childList: true, subtree: true });

// Periodically check and ensure our content is hidden if it should be
setInterval(() => {
    if (isContentHidden) {
        initializeSite();
    }
}, 1000);